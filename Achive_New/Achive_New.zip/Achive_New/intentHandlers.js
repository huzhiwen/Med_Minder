/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

'use strict';
var textHelper = require('./textHelper'),
    storage = require('./storage');

var registerIntentHandlers = function (intentHandlers, skillContext) {
    intentHandlers.NewGameIntent = function (intent, session, response) {
        //reset scores for all existing players
        storage.loadGame(session, function (currentGame) {
            if (currentGame.data.players.length === 0) {
                response.ask('New Medicine list created. You can start to add medicine to your medicine list and set how many times you need to take each medicine today. What\'s your first medicine?',
                    'Please tell me what\'s your first medicine?');
                return;
            }
            currentGame.data.players.forEach(function (player) {
                currentGame.data.scores[player] = 0;
            });
            currentGame.save(function () {
                var speechOutput = 'New day started with '
                    + currentGame.data.players.length + ' existing medicine.' + 'You can now set your new count';
                if (currentGame.data.players.length > 1) {
                    speechOutput += 's';
                }
                speechOutput += '.';
                if (skillContext.needMoreHelp) {
                    speechOutput += '. You can set number of times to a medicine, add another medicine, reset medicine list or exit. What would you like?';
                    var repromptText = 'You can set number of times to a medicine, add another medicine, reset medicine list or exit. What would you like?';
                    response.ask(speechOutput, repromptText);
                } else {
                    response.tell(speechOutput);
                }
            });
        });
    };

    intentHandlers.AddPlayerIntent = function (intent, session, response) {
        //add a player to the current game,
        //terminate or continue the conversation based on whether the intent
        //is from a one shot command or not.
        var newPlayerName = textHelper.getPlayerName(intent.slots.MedicineName.value);
        if (!newPlayerName) {
            response.ask('OK. What do you want to add?', 'What do you want to add?');
            return;
        }
        storage.loadGame(session, function (currentGame) {
            var speechOutput,
                reprompt;
            if (currentGame.data.scores[newPlayerName] !== undefined) {
                speechOutput = newPlayerName + ' has been already added to the medicine list.';
                if (skillContext.needMoreHelp) {
                    response.ask(speechOutput + ' What else?', 'What else?');
                } else {
                    response.tell(speechOutput);
                }
                return;
            }
            speechOutput = newPlayerName + '.added to your medicine list. ';
            currentGame.data.players.push(newPlayerName);
            currentGame.data.scores[newPlayerName] = 0;
            if (skillContext.needMoreHelp) {
                if (currentGame.data.players.length == 1) {
                    speechOutput += 'You can say, I am Done Adding Medicines. Now what\'s your next medicine?';
                    reprompt = textHelper.nextHelp;
                } else {
                    speechOutput += 'What is your next medicine?';
                    reprompt = textHelper.nextHelp;
                }
            }
            currentGame.save(function () {
                if (reprompt) {
                    response.ask(speechOutput, reprompt);
                } else {
                    response.tell(speechOutput);
                }
            });
        });
    };

    intentHandlers.AddScoreIntent = function (intent, session, response) {
        //give a player points, ask additional question if slot values are missing.
        var playerName = textHelper.getPlayerName(intent.slots.MedicineName.value),
            score = intent.slots.NumberOfTimes,
            upperbound  = intent.slots.UpperBound,
            scoreValue;
        if (!playerName) {
            response.ask('sorry, I did not hear the medicine name, please say that again', 'Please say the name again');
            return;
        }
        scoreValue = parseInt(score.value);
        upperboundValue = parseInt(upperbound.value);        

        if (isNaN(scoreValue)) {
            console.log('Invalid count value = ' + score.value);
            response.ask('sorry, I did not hear the number, could you please say that again', 'please say the number again');
            return;
        }

        if (isNaN(upperboundValue)) {
            console.log('Invalid upperbound value = ' + upperbound.value);
            response.ask('sorry, I did not hear the number, could you please say that again', 'please say the number again');
            return;
        }  

        storage.loadGame(session, function (currentGame) {
            var targetPlayer, speechOutput = '', newScore;
            if (currentGame.data.players.length < 1) {
                response.ask('sorry, no medicine is in the medicine list, what can I do for you?', 'what can I do for you?');
                return;
            }
            for (var i = 0; i < currentGame.data.players.length; i++) {
                if (currentGame.data.players[i] === playerName) {
                    targetPlayer = currentGame.data.players[i];
                    break;
                }
            }
            if (!targetPlayer) {
                response.ask('Sorry, ' + playerName + ' is not in the medicine list. What else?', playerName + ' is not in the medicine list. What else?');
                return;
            }
            newScore = currentGame.data.scores[targetPlayer] + scoreValue;
            currentGame.data.scores[targetPlayer] = newScore;
            currentGame.data.upperbounds[targetPlayer] = upperboundValue;            

            speechOutput += 'You just assign upperbound value:' + upperboundValue + ' for ' + targetPlayer + '. ';
            speechOutput += scoreValue + ' for ' + targetPlayer + '. ';
            if (currentGame.data.players.length == 1 || currentGame.data.players.length > 3) {
                speechOutput += 'There are ' + newScore + 'number of times for' + targetPlayer + 'in total.';
            } else {
                speechOutput += 'That\'s ';
                currentGame.data.players.forEach(function (player, index) {
                    if (index === currentGame.data.players.length - 1) {
                        speechOutput += 'And ';
                    }
                    speechOutput += player + ', ' + currentGame.data.scores[player];
                    speechOutput += ', ';
                });
            }
            currentGame.save(function () {
                response.tell(speechOutput);
            });
        });
    };

    intentHandlers.TellScoresIntent = function (intent, session, response) {
        //tells the scores in the leaderboard and send the result in card.
        storage.loadGame(session, function (currentGame) {
            var sortedPlayerScores = [],
                continueSession,
                speechOutput = '',
                leaderboard = '';
            if (currentGame.data.players.length === 0) {
                response.tell('Your medicine list is empty');
                return;
            }
            currentGame.data.players.forEach(function (player) {
                sortedPlayerScores.push({
                    score: currentGame.data.scores[player],
                    player: player
                });
            });
            sortedPlayerScores.sort(function (p1, p2) {
                return p2.score - p1.score;
            });
            sortedPlayerScores.forEach(function (playerScore, index) {
                if (index === 0) {
                    speechOutput += 'You have taken' + playerScore.player  + playerScore.score + 'time';
                    if (playerScore.score > 1) {
                        speechOutput += 's';
                    }
                } else if (index === sortedPlayerScores.length - 1) {
                    speechOutput += 'And you have taken' + playerScore.player  + playerScore.score + 'time';
                } else {
                    speechOutput += playerScore.player + ', ' + playerScore.score;
                }
                speechOutput += '. ';
                leaderboard += 'No.' + (index + 1) + ' - ' + playerScore.player + ' : ' + playerScore.score + '\n';
            });
            response.tellWithCard(speechOutput, "Leaderboard", leaderboard);
        });
    };

    intentHandlers.ResetPlayersIntent = function (intent, session, response) {
        //remove all players
        storage.newGame(session).save(function () {
            response.ask('You just cleaned your medicine list, what medicine do you want to add first?', 'what medicine do you want to add first?');
        });
    };


    // intentHandlers.SetUpperBoundIntent = function (intent, session, response) {
    //     var playerName = textHelper.getPlayerName(intent.slots.MedicineName.value),
    //         score = intent.slots.NumberOfTimes,
    //         scoreValue;
    //     if (!playerName) {
    //         response.ask('sorry, I did not hear the medicine name, please say that again', 'Please say the name again');
    //         return;
    //     }
    //     scoreValue = parseInt(score.value);
    //     if (isNaN(scoreValue)) {
    //         console.log('Invalid count value = ' + score.value);
    //         response.ask('sorry, I did not hear the number, could you please say that again', 'please say the number again');
    //         return;
    //     }
    //     storage.loadGame(session, function (currentGame) {
    //         var targetPlayer, speechOutput = '', newScore;
    //         if (currentGame.data.players.length < 1) {
    //             response.ask('sorry, no medicine is in the medicine list, what can I do for you?', 'what can I do for you?');
    //             return;
    //         }
    //         for (var i = 0; i < currentGame.data.players.length; i++) {
    //             if (currentGame.data.players[i] === playerName) {
    //                 targetPlayer = currentGame.data.players[i];
    //                 break;
    //             }
    //         }
    //         if (!targetPlayer) {
    //             response.ask('Sorry, ' + playerName + ' is not in the medicine list. What else?', playerName + ' is not in the medicine list. What else?');
    //             return;
    //         }
    //         newScore = currentGame.data.scores[targetPlayer] + scoreValue;
    //         currentGame.data.scores[targetPlayer] = newScore;

    //         speechOutput += scoreValue + ' for ' + targetPlayer + '. ';
    //         if (currentGame.data.players.length == 1 || currentGame.data.players.length > 3) {
    //             speechOutput += 'There are ' + newScore + 'number of times for' + targetPlayer + 'in total.';
    //         } else {
    //             speechOutput += 'That\'s ';
    //             currentGame.data.players.forEach(function (player, index) {
    //                 if (index === currentGame.data.players.length - 1) {
    //                     speechOutput += 'And ';
    //                 }
    //                 speechOutput += player + ', ' + currentGame.data.scores[player];
    //                 speechOutput += ', ';
    //             });
    //         }
    //         currentGame.save(function () {
    //             response.tell(speechOutput);
    //         });
    //     });
    // };    

    intentHandlers['AMAZON.HelpIntent'] = function (intent, session, response) {
        var speechOutput = textHelper.completeHelp;
        if (skillContext.needMoreHelp) {
            response.ask(textHelper.completeHelp + ' So, how can I help?', 'How can I help?');
        } else {
            response.tell(textHelper.completeHelp);
        }
    };

    intentHandlers['AMAZON.CancelIntent'] = function (intent, session, response) {
        if (skillContext.needMoreHelp) {
            response.tell('Okay.  Whenever you\'re ready, you can start setting number of times to the medicine in your list.');
        } else {
            response.tell('');
        }
    };

    intentHandlers['AMAZON.StopIntent'] = function (intent, session, response) {
        if (skillContext.needMoreHelp) {
            response.tell('Okay.  Whenever you\'re ready, you can start setting number of times to the medicine in your list');
        } else {
            response.tell('');
        }
    };
};

exports.register = registerIntentHandlers;
